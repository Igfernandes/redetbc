<?php
namespace Modules\Hotel\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Modules\AdminController;
use Modules\Core\Models\Attributes;
use Modules\Core\Models\AttributesTranslation;
use Modules\Core\Models\Terms;
use Modules\Core\Models\TermsTranslation;
use Illuminate\Support\Facades\DB;

class RoomAttributeController extends AdminController
{
    protected $attributesClass;
    protected $termsClass;
    public function __construct()
    {
        $this->setActiveMenu(route('hotel.admin.index'));
        $this->attributesClass = Attributes::class;
        $this->termsClass = Terms::class;
    }

    public function index(Request $request)
    {
        $this->checkPermission('hotel_manage_attributes');
        $listAttr = $this->attributesClass::where("service", 'hotel_room');
        if (!empty($search = $request->query('s'))) {
            $listAttr->where('name', 'LIKE', '%' . $search . '%');
        }
        $listAttr->orderBy('created_at', 'desc');
        $data = [
            'rows'        => $listAttr->get(),
            'row'         => new $this->attributesClass(),
            'translation'    => new AttributesTranslation(),
            'breadcrumbs' => [
                [
                    'name' => __('Hotel'),
                    'url'  => route('hotel.admin.index')
                ],
                [
                    'name'  => __('Atributos do Quarto'),
                    'class' => 'active'
                ],
            ]
        ];
        return view('Hotel::admin.room.attribute.index', $data);
    }

    public function edit(Request $request, $id)
    {
        $row = $this->attributesClass::find($id);
        if (empty($row)) {
            return redirect()->back()->with('error', __('Atributos não encontrados!'));
        }
        $translation = $row->translate($request->query('lang',get_main_lang()));
        $this->checkPermission('hotel_manage_attributes');
        $data = [
            'translation'    => $translation,
            'enable_multi_lang'=>true,
            'rows'        => $this->attributesClass::where("service", 'hotel_room')->get(),
            'row'         => $row,
            'breadcrumbs' => [
                [
                    'name' => __('Hotel'),
                    'url'  => route('hotel.admin.index')
                ],
                [
                    'name' => __('Atributos do Quarto'),
                    'url'  => route('hotel.admin.room.attribute.index')
                ],
                [
                    'name'  => __('Atributo: :name', ['name' => $row->name]),
                    'class' => 'active'
                ],
            ]
        ];
        return view('Hotel::admin.room.attribute.detail', $data);
    }

    public function store(Request $request)
    {
        $this->checkPermission('hotel_manage_attributes');
        $this->validate($request, [
            'name' => 'required'
        ]);
        $id = $request->input('id');
        if ($id) {
            $row = $this->attributesClass::find($id);
            if (empty($row)) {
                return redirect()->back()->with('error', __('Atributos não encontrados!'));
            }
        } else {
            $row = new $this->attributesClass($request->input());
            $row->service = 'hotel_room';
        }
        $row->fill($request->input());
        $res = $row->saveOriginOrTranslation($request->input('lang'));
        if ($res) {
            return redirect()->back()->with('success', __('Atributo salvo'));
        }
    }

    public function editAttrBulk(Request $request)
    {
        $this->checkPermission('hotel_manage_attributes');
        $ids = $request->input('ids');
        $action = $request->input('action');
        if (empty($ids) or !is_array($ids)) {
            return redirect()->back()->with('error', __('Selecione pelo menos 1 item!'));
        }
        if (empty($action)) {
            return redirect()->back()->with('error', __('Selecione uma ação!'));
        }
        if ($action == "delete") {
            foreach ($ids as $id) {
                $query = $this->attributesClass::where("id", $id);
                $query->first();
                if(!empty($query)){
                    $query->delete();
                }
            }
        }
        return redirect()->back()->with('success', __('Atualizado com sucesso!'));
    }

    public function terms(Request $request, $attr_id)
    {
        $this->checkPermission('hotel_manage_attributes');
        $row = $this->attributesClass::find($attr_id);
        if (empty($row)) {
            return redirect()->back()->with('error', __('Termo não encontrado'));
        }
        $listTerms = $this->termsClass::where("attr_id", $attr_id);
        if (!empty($search = $request->query('s'))) {
            $listTerms->where('name', 'LIKE', '%' . $search . '%');
        }
        $listTerms->orderBy('created_at', 'desc');
        $data = [
            'rows'        => $listTerms->paginate(20),
            'attr'        => $row,
            "row"         => new $this->termsClass(),
            'translation'    => new TermsTranslation(),
            'breadcrumbs' => [
                [
                    'name' => __('Hotel'),
                    'url'  => route('hotel.admin.index')
                ],
                [
                    'name' => __('Atributos do Quarto'),
                    'url'  => route('hotel.admin.room.attribute.index')
                ],
                [
                    'name'  => __('Atributo: :name', ['name' => $row->name]),
                    'class' => 'active'
                ],
            ]
        ];
        return view('Hotel::admin.terms.index', $data);
    }

    public function term_edit(Request $request, $id)
    {
        $this->checkPermission('hotel_manage_attributes');
        $row = $this->termsClass::find($id);
        if (empty($row)) {
            return redirect()->back()->with('error', __('Termo não encontrado'));
        }
        $translation = $row->translate($request->query('lang',get_main_lang()));
        $attr = $this->attributesClass::find($row->attr_id);
        $data = [
            'row'         => $row,
            'translation'    => $translation,
            'enable_multi_lang'=>true,
            'breadcrumbs' => [
                [
                    'name' => __('Hotel'),
                    'url'  => route('hotel.admin.index')
                ],
                [
                    'name' => __('Atributos do Quarto'),
                    'url'  => route('hotel.admin.room.attribute.index')
                ],
                [
                    'name' => $attr->name,
                    'url'  => route('hotel.admin.room.attribute.term.index',['id'=>$row->attr_id])
                ],
                [
                    'name'  => __('Termo: :name', ['name' => $row->name]),
                    'class' => 'active'
                ],
            ]
        ];
        return view('Hotel::admin.terms.detail', $data);
    }

    public function term_store(Request $request)
    {
        $this->checkPermission('hotel_manage_attributes');
        $this->validate($request, [
            'name' => 'required'
        ]);
        $id = $request->input('id');
        if ($id) {
            $row = $this->termsClass::find($id);
            if (empty($row)) {
                return redirect()->back()->with('error', __('Termo não encontrado'));
            }
        } else {
            $row = new $this->termsClass($request->input());
            $row->attr_id = $request->input('attr_id');
        }
        $row->fill($request->input());
        $row->image_id = $request->input('image_id');
        $row->icon = $request->input('icon');
        $res = $row->saveOriginOrTranslation($request->input('lang'));
        if ($res) {
            return redirect()->back()->with('success', __('Termo salvo'));
        }
    }

    public function editTermBulk(Request $request)
    {
        $this->checkPermission('hotel_manage_attributes');
        $ids = $request->input('ids');
        $action = $request->input('action');
        if (empty($ids) or !is_array($ids)) {
            return redirect()->back()->with('error', __('Selecione pelo menos 1 item!'));
        }
        if (empty($action)) {
            return redirect()->back()->with('error', __('Selecione uma ação!'));
        }
        if ($action == "delete") {
            foreach ($ids as $id) {
                $query = $this->termsClass::where("id", $id);
                $query->first();
                if(!empty($query)){
                    $query->delete();
                }
            }
        }
        return redirect()->back()->with('success', __('Atualizado com sucesso!'));
    }

    public function getForSelect2(Request $request)
    {
        $pre_selected = $request->query('pre_selected');
        $selected = $request->query('selected');

        if($pre_selected && $selected){
            if(is_array($selected))
            {
                $query = $this->termsClass::getForSelect2Query('hotel_room');
                $items = $query->whereIn('bravo_terms.id',$selected)->take(50)->get();

            }else{
                $items = $this->termsClass::find($selected);
            }

            return [
                'results'=>$items
            ];
        }
        $q = $request->query('q');
        $query = $this->termsClass::getForSelect2Query('hotel_room',$q);
        $res = $query->orderBy('bravo_terms.id', 'desc')->limit(20)->get();
        return response()->json([
            'results' => $res
        ]);
    }
}
