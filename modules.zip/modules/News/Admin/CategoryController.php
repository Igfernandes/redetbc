<?php
namespace Modules\News\Admin;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Modules\AdminController;
use Modules\News\Models\NewsCategory;
use Illuminate\Support\Str;
use Modules\News\Models\NewsCategoryTranslation;

class CategoryController extends AdminController
{
    public function __construct()
    {
        $this->setActiveMenu(route('news.admin.index'));
    }

    public function index(Request $request)
    {
        $this->checkPermission('news_manage_others');

        $catlist = new NewsCategory;
        if ($catename = $request->query('s')) {
            $catlist = $catlist->where('name', 'LIKE', '%' . $catename . '%');
        }
        $catlist = $catlist->orderby('name', 'asc');
        $rows = $catlist->get();

        $data = [
            'rows'        => $rows->toTree(),
            'row'         => new NewsCategory(),
            'breadcrumbs' => [
                [
                    'name' => __('Notícias'),
                    'url'  => route('news.admin.index')
                ],
                [
                    'name'  => __('Categoria'),
                    'class' => 'active'
                ],
            ],
            'translation'=>new NewsCategoryTranslation()
        ];
        return view('News::admin.category.index', $data);
    }

    public function edit(Request $request, $id)
    {
        $this->checkPermission('news_manage_others');
        $row = NewsCategory::find($id);

        $translation = $row->translate($request->query('lang',get_main_lang()));

        if (empty($row)) {
            return redirect(route('news.admin.category.index'));
        }
        $data = [
            'row'     => $row,
            'translation'     => $translation,
            'parents' => NewsCategory::get()->toTree(),
            'enable_multi_lang'=>true
        ];
        return view('News::admin.category.detail', $data);
    }

    public function store(Request $request, $id){
        $this->checkPermission('news_manage_others');

        if($id>0){
            $row = NewsCategory::find($id);
            if (empty($row)) {
                return redirect(route('news.admin.category.index'));
            }
        }else{
            $row = new NewsCategory();
            $row->status = "publish";
        }
        $row->fill($request->input());
        if($request->input('slug')){
            $row->slug = $request->input('slug');
        }
        $res = $row->saveOriginOrTranslation($request->input('lang'));

        if ($res) {
            if($id > 0 ){
                return back()->with('success',  __('Categoria atualizada') );
            }else{
                return redirect(route('news.admin.category.index'))->with('success', __('Categoria criada') );
            }
        }
    }

    public function bulkEdit(Request $request)
    {
        $this->checkPermission('news_manage_others');
        $ids = $request->input('ids');
        $action = $request->input('action');
        if (empty($ids) or !is_array($ids)) {
            return redirect()->back()->with('error', __('Please select at least 1 item!'));
        }
        if (empty($action)) {
            return redirect()->back()->with('error', __('Selecione uma ação!'));
        }
        if ($action == 'delete') {
            foreach ($ids as $id) {
                $query = NewsCategory::where("id", $id)->first();
                if(!empty($query)){
                    $query->delete();
                }
            }
        }
        return redirect()->back()->with('success', __('Atualização bem-sucedida!'));
    }

    public function getForSelect2(Request $request)
    {
        $pre_selected = $request->query('pre_selected');
        $selected = $request->query('selected');

        if($pre_selected && $selected){
            $items = NewsCategory::find($selected);

            return [
                'results'=>$items
            ];
        }
        $q = $request->query('q');
        $query = NewsCategory::select('id', 'name as text')->where("status","publish");
        if ($q) {
            $query->where('name', 'like', '%' . $q . '%');
        }
        $res = $query->orderBy('id', 'desc')->limit(20)->get();
        return response()->json([
            'results' => $res
        ]);
    }
}
