@if(is_default_lang())
    <hr>
    <div class="panel">
        <div class="panel-title"><strong>{{__("Campos de pesquisa no mapa")}}</strong></div>
        <div class="panel-body">
            <div class="form-group" >
                <label class="" >{{__("Critérios de pesquisa")}}</label>
                <div class="form-controls">
                    <div class="form-group-item">
                        <div class="g-items-header">
                            <div class="row">
                                <div class="col-md-7">{{__("Campo de pesquisa")}}</div>
                                <div class="col-md-4">{{__("Ordem")}}</div>
                                <div class="col-md-1"></div>
                            </div>
                        </div>
                        <div class="g-items">
                            @php
                            $event_map_search_fields = setting_item_array('event_map_search_fields');
                            $types = [
                                'location'=>__("Localização"),
                                'attr'=>__("Atributo"),
                                'date'=>__("Data"),
                                'price'=>__("Preço"),
                                'advance'=>__("Avançar"),
                            ];
                            $attrs = \Modules\Core\Models\Attributes::where('service', 'event')->get();
                            @endphp
                            @foreach($event_map_search_fields as $key=>$item)
                                <div class="item" data-number="{{$key}}">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <select name="event_map_search_fields[{{$key}}][field]" class="custom-select">
                                                <option value="">{{__("-- Selecione o tipo de campo --")}}</option>
                                                @foreach($types as $type=>$name)
                                                    <option @if($item['field'] == $type) selected @endif value="{{$type}}">{{$name}}</option>
                                                @endforeach
                                            </select>
                                            <br>
                                            <select name="event_map_search_fields[{{$key}}][attr]" class="mt-2 custom-select">
                                                <option value="">{{__("-- Selecione o atributo --")}}</option>
                                                @foreach($attrs as $attr)
                                                    <option @if($item['attr'] == $attr->id) selected @endif value="{{$attr->id}}">{{$attr->name}}</option>
                                                @endforeach
                                            </select>


                                        </div>
                                        <div class="col-md-4">
                                            <input type="number" name="event_map_search_fields[{{$key}}][position]" min="0" value="{{$item['position'] ?? 0}}" class="form-control">
                                        </div>
                                        <div class="col-md-1">
                                            <span class="btn btn-danger btn-sm btn-remove-item"><i class="fa fa-trash"></i></span>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                        <div class="text-right">
                            <span class="btn btn-info btn-sm btn-add-item"><i class="icon ion-ios-add-circle-outline"></i> {{__('Adicionar item')}}</span>
                        </div>
                        <div class="g-more hide">
                            <div class="item" data-number="__number__">
                                <div class="row">
                                    <div class="col-md-7">
                                        <select __name__="event_map_search_fields[__number__][field]" class="custom-select">
                                            <option value="">{{__("-- Selecione o tipo de campo --")}}</option>
                                            @foreach($types as $type=>$name)
                                                <option value="{{$type}}">{{$name}}</option>
                                            @endforeach
                                        </select>
                                        <select __name__="event_map_search_fields[__number__][attr]" class=" mt-2  custom-select">
                                            <option value="">{{__("-- Selecione o atributo --")}}</option>
                                            @foreach($attrs as $attr)
                                                <option value="{{$attr->id}}">{{$attr->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="number" __name__="event_map_search_fields[__number__][position]" min="0"  class="form-control">
                                    </div>
                                    <div class="col-md-1">
                                        <span class="btn btn-danger btn-sm btn-remove-item"><i class="fa fa-trash"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <hr>
@endif
