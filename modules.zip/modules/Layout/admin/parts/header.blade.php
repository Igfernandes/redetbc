<?php

$user = Auth::user();

[$notifications, $countUnread] = getNotify();



$languages = \Modules\Language\Models\Language::getActive();

$locale = App::getLocale();

$theme = \Modules\Theme\ThemeManager::currentProvider();

?>



<div class="header-logo flex-shrink-0">

    <h3 class="logo-text">

        <img border="0" src="https://www.agencianaweb.com.br/www.agencianaweb.com.br-painel-white.png" width="50%">

    </h3>

</div>

<div class="header-widgets d-flex flex-grow-1">

    <div class="widgets-left d-flex flex-grow-1 align-items-center">

        <div class="header-widget">

            <span class="btn-toggle-admin-menu btn btn-sm btn-link"><i class="icon ion-ios-menu"></i></span>

        </div>

        <div class="header-widget search-widget">

            {{--<input type="text" class="input-search form-control">--}}

            <a href="{{url('/')}}" class="btn btn-link" target="_blank"><i class="fa fa-eye"></i> <span translate="no">{{__('Home')}} </span>

            </a>

        </div>

    </div>

    <div class="widgets-right flex-shrink-0 d-flex">

        <div class="dropdown header-widget widget-user pt-2 dropdown-notifications flex-shrink-0" style="min-width: 0">

            <div data-toggle="dropdown" class="user-dropdown d-flex align-items-center" aria-haspopup="true" aria-expanded="false">

                <i class="fa fa-lg fa-bell m-1 p-1"></i>

                <span class="badge badge-danger notification-icon">{{$countUnread > 10 ? "+9" : $countUnread}}</span>

            </div>

            <div class="dropdown-menu overflow-auto notify-items dropdown-container dropdown-menu-right dropdown-large" aria-labelledby="dropdownMenuButton">

                <div class="dropdown-toolbar">

                    <div class="dropdown-toolbar-actions">

                        <a href="#" class="markAllAsRead">{{__('Marcar todos como lido')}}</a>

                    </div>

                    <h3 class="dropdown-toolbar-title">{{__('Notificações')}} (<span class="notif-count">{{$countUnread}}</span>)</h3>

                </div>

                <ul class="dropdown-list-items p-0 m-0">

                    @if(count($notifications)> 0)

                    @foreach($notifications as $oneNotification)

                    @php

                    $active = $class = '';

                    $data = json_decode($oneNotification['data']);



                    $idNotification = @$data->id;

                    $forAdmin = @$data->for_admin;

                    $usingData = @$data->notification;



                    $services = @$usingData->type;

                    $idServices = @$usingData->id;

                    $title = @$usingData->message;

                    $name = @$usingData->name;

                    $avatar = @$usingData->avatar;

                    $link = @$usingData->link;



                    if(empty($oneNotification->read_at)){

                    $class = 'markAsRead';

                    $active = 'active';

                    }



                    @endphp

                    <li class="notification {{$active}}">

                        <a class="{{$class}}" data-id="{{$idNotification}}" href="{{$link}}">

                            <div class="media">

                                <div class="media-left">

                                    <div class="media-object">

                                        @if($avatar)

                                        <img class="image-responsive" src="{{$avatar}}" alt="{{$name}}">

                                        @else

                                        <span class="avatar-text">{{ucfirst($name[0])}}</span>

                                        @endif

                                    </div>

                                </div>

                                <div class="media-body">

                                    {!! $title !!}

                                    <div class="notification-meta">

                                        <small class="timestamp">{{format_interval($oneNotification->created_at)}}</small>

                                    </div>

                                </div>

                            </div>

                        </a>

                    </li>

                    @endforeach

                    @endif

                </ul>

                <div class="dropdown-footer text-center">

                    <a href="{{route('core.admin.notification.loadNotify')}}">{{__('Ver Mais')}}</a>

                </div>

            </div>

        </div>

        <div class="dropdown header-widget widget-user flex-shrink-0">

            <div data-toggle="dropdown" class="user-dropdown d-flex align-items-center" aria-haspopup="true" aria-expanded="false">

                <span class="user-avatar flex-shrink-0">

                    @if($avatar_url = $user->getAvatarUrl())

                    <div class="avatar avatar-cover" style="background-image: url('{{$user->getAvatarUrl()}}')"></div>

                    @else

                    <span class="avatar-text">{{ucfirst($user->getDisplayName()[0])}}</span>

                    @endif

                </span>

                <div class="user-info flex-grow-1">

                    <div class="user-name">{{$user->getDisplayName()}}</div>

                    <div class="user-role">{{ucfirst($user->role->name ?? '')}}</div>

                </div>

                <i class="fa fa-angle-down"></i>

            </div>

            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                <a class="dropdown-item" href="{{route('user.admin.detail',['id'=>$user->id])}}">{{__('Editar Profile')}}</a>

                <a class="dropdown-item" href="{{route('user.admin.password',['id'=>$user->id])}}">{{__('Alterar Senha')}}</a>

                <div class="dropdown-divider"></div>

                <h6 class="dropdown-header">{{__("Fornecedor Dashboard")}}</h6>

                <a href="{{route('vendor.dashboard')}}" class="dropdown-item">{{__("Dashboard")}}</a>

                <div class="dropdown-divider"></div>

                <a href="{{url('/')}}" class="dropdown-item"><i class="fa fa-home"></i> {{__("Homepage")}}</a>

                <div class="dropdown-divider"></div>

                <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> {{__('Sair')}}

                </a>

            </div>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">

                {{ csrf_field() }}

            </form>

        </div>

    </div>

</div>