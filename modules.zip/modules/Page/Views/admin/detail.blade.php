@extends('admin.layouts.app')

@section('content')

<form action="{{route('page.admin.store',['id'=>($row->id) ? $row->id : '-1','lang'=>request()->query('lang')])}}" method="post">
    @csrf
    <div class="container">
        <div class="d-flex justify-content-between mb20">
            <div class="">
                <h1 class="title-bar">{{$row->id ? __('Editar: ') .$translation->title :  __('Adicionar nova página') }}</h1>
                @if($row->slug)
                <p class="item-url-demo">{{ __('Permalink: ')}} {{ url((request()->query('lang') ? request()->query('lang').'/' : ''). config('page.page_route_prefix') )}}/<a href="#" class="open-edit-input" data-name="slug">{{$row->slug}}</a>
                </p>
                @endif
            </div>
            <div class="">
                @if($row->id)
                <a class="btn btn-primary btn-sm" href="{{route('page.admin.builder',['id'=>$row->id])}}"><i class="fa fa-paint-brush"></i> {{ __('Template Builder')}}</a>
                @endif
                @if($row->slug)
                <a class="btn btn-primary btn-sm" href="{{$row->getDetailUrl(request()->query('lang'))}}" target="_blank">{{ __('View page')}}</a>
                @endif
            </div>
        </div>
        @include('admin.message')
        @if($row->id)
        @include('Language::admin.navigation')
        @endif
        <div class="lang-content-box">
            <div class="row">
                <div class="col-md-9">
                    <div class="panel">
                        <div class="panel-title">
                            <strong>{{ __('Página Content')}}</strong>
                        </div>
                        <div class="panel-body">
                            <div class="form-group magic-field" data-id="title" data-type="title">
                                <label class="control-label">{{__("Título")}}</label>
                                <input
                                    type="text"
                                    value="{{$translation->title}}"
                                    placeholder="{{__("Título")}}"
                                    name="title"
                                    class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="control-label">{{__("Religião")}}</label>
                                <select name="religion" class="form-control">
                                    <option value="">Selecione a religião</option>
                                    <option value="CATHOLIC" @if($row->religion == "CATHOLIC") selected @endif > {{__("Evangélico")}}</option>
                                    <option value="EVANGELICAL" @if($row->religion == "EVANGELICAL") selected @endif > {{__("Católico")}}</option>
                                    <option value="BOTH" @if($row->religion == "BOTH") selected @endif > {{__("Ambos")}}</option>
                                </select>
                            </div>
                            <div class="form-group magic-field" data-id="content" data-type="content">
                                <label class="control-label">{{__("Conteúdo")}}</label>
                                <div class="">
                                    <textarea
                                        name="content"
                                        class="d-none has-ckeditor"
                                        id="content"
                                        cols="30"
                                        rows="10">{{$translation->content}}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    @include('Core::admin/seo-meta/seo-meta')
                </div>
                <div class="col-md-3">
                    <div class="panel">
                        <div class="panel-title"><strong>{{__('Publicar')}}</strong></div>
                        <div class="panel-body">
                            @if(is_default_lang())
                            <div>
                                <label><input @if($row->status=='publish') checked @endif type="radio" name="status" value="publish"> {{__("Publicar")}}
                                </label>
                            </div>
                            <div>
                                <label><input @if($row->status=='draft') checked @endif type="radio" name="status" value="draft"> {{__("Rascunho")}}
                                </label>
                            </div>
                            @endif
                            <div class="text-right">
                                <button class="btn btn-primary" type="submit"><i class="fa fa-save"></i> {{__('Salvar alterações')}}</button>
                            </div>
                        </div>
                    </div>
                    @if(is_default_lang())
                    @include('Page::admin.advanced')
                    <div class="panel">
                        <div class="panel-body">
                            <h3 class="panel-body-title">{{ __('Logo')}}</h3>
                            <div class="form-group">
                                {!! \Modules\Media\Helpers\FileHelper::fieldUpload('custom_logo',$row->custom_logo) !!}
                            </div>
                        </div>
                    </div>
                    <div class="panel">
                        <div class="panel-body">
                            <h3 class="panel-body-title">{{ __('Imagem em destaque')}}</h3>
                            <div class="form-group">
                                {!! \Modules\Media\Helpers\FileHelper::fieldUpload('image_id',$row->image_id) !!}
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</form>
@endsection