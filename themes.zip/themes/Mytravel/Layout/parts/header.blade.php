<style>

    .js-header-fix-moment {
        box-shadow: 1px 1px 4px #dddddd;
    }

    .js-header-fix-moment .filter-key span {
        color: black;
    }

    .js-header-fix-moment .filter-key i {
        color: #003583;
    }
</style>
<?php
$religion = null;

if (isset($_GET['religion'])) {
    session(['FILTER_RELIGION' => $_GET['religion']]);
    $religion = session('FILTER_RELIGION');
}
?>
<header id="header"
    class="@if(!empty($is_home) or !empty($header_transparent))

            u-header u-header--abs-top u-header--white-nav-links-xl u-header--bg-transparent u-header--show-hide border-bottom border-xl-bottom-0 border-color-white

        @else

            header-white u-header u-header--dark-nav-links-xl u-header--show-hide-xl u-header--static-xl border-bottom

        @endif"

    data-header-fix-moment="500" data-header-fix-effect="slide">
    @if(Auth::user() == null || !Auth::user()->user_plan)
    <div class="subscribe-plan">
        <div class="content">
            <p>
                {{ __("Junte-se ao clube: escolha seu plano e tenha acesso completo.") }}
            </p> &nbsp;

            @if(Auth::user() == null)
            <a data-target="#register" data-toggle="modal">{{ __("Cadastra-se agora") }}</a>
            @else
            <a href="/plan">{{ __("Cadastra-se agora") }}</a>
            @endif
        </div>
    </div>
    @endif

    @if(hasUpgradePlanRequest() && !Route::is('user.upgrade_vendor_plans'))
    <div class="upgrade-plan ">
        <div class="content d-flex justify-content-center text-center py-2 bg-warning">
            <p class="mb-0">
                {{ __("Your plan upgrade request has been approved.") }}
            </p> &nbsp;&nbsp;
            <a href="{{route('user.upgrade_vendor_plans')}}">{{ __("Complete the plan upgrade") }}</a>
        </div>
    </div>
    @endif

    <div class="u-header__section u-header__shadow-on-show-hide">

        @include('Layout::parts.topbar')

        <div class="bravo_header">

            <div class="{{$container_class ?? 'container'}}">

                <div class="content">

                    <div class="header-left">

                        <div class="d-flex align-items-center" style="cursor: pointer;">
                            <a href="{{url(app_get_locale(false,'/'))}}" class="bravo-logo navbar-brand u-header__navbar-brand-default u-header__navbar-brand-center u-header__navbar-brand-text-white mr-0 mr-xl-5">

                                @if($logo_id = setting_item("logo_id"))

                                <?php $logo = get_file_url($logo_id, 'full') ?>

                                <img src="{{$logo}}" alt="{{setting_item("site_title")}}">

                                @endif

                            </a>

                            <a class="bravo-logo navbar-brand u-header__navbar-brand u-header__navbar-brand-center u-header__navbar-brand-on-scroll" href="{{url(app_get_locale(false,'/'))}}">

                                @if($logo_id = setting_item("logo_id_2"))

                                <?php $logo = get_file_url($logo_id, 'full') ?>

                                <img src="{{$logo}}" alt="{{setting_item("site_title")}}">

                                @endif


                            </a>

                            <div class="filter-key  ml-2">
                                <a href="./?religion=CATHOLIC">
                                    <span class="text" @if($religion==="CATHOLIC" ) style="color: #ffa636;" @endif>
                                        {{ __('Católico') }}
                                    </span>
                                </a>
                                <i class="icofont-key"></i>
                                <a href="./?religion=EVANGELIC">
                                    <span class="text" @if($religion==="EVANGELIC" ) style="color: #ffa636;" @endif>
                                        {{ __('Evangélico') }}
                                    </span>
                                </a>
                            </div>
                        </div>

                        <div class="bravo-menu">

                            <?php generate_menu('primary') ?>

                        </div>

                    </div>

                    <div class="header-right">

                        @if(!empty($header_right_menu))

                        <ul class="topbar-items">

                            @include('Core::frontend.currency-switcher')

                            @if(!Auth::id())

                            <li class="login-item">

                                <a href="#login" data-toggle="modal" data-target="#login" class="login">{{__('Login')}}</a>

                            </li>

                            <li class="signup-item">

                                <a href="#register" data-toggle="modal" data-target="#register" class="signup">{{__('Sign Up')}}</a>

                            </li>

                            @else

                            <li class="login-item dropdown">

                                <a href="#" data-toggle="dropdown" class="is_login">

                                    @if($avatar_url = Auth::user()->getAvatarUrl())

                                    <img class="avatar" src="{{$avatar_url}}" alt="{{ Auth::user()->getDisplayName()}}">

                                    @else

                                    <span class="avatar-text">{{ucfirst( Auth::user()->getDisplayName()[0])}}</span>

                                    @endif

                                    {{__("Oi, :Name",['name'=>Auth::user()->getDisplayName()])}}

                                    <i class="fa fa-angle-down"></i>

                                </a>

                                <ul class="dropdown-menu text-left">



                                    @if(Auth::user()->hasPermission('dashboard_vendor_access'))

                                    <li><a href="{{route('vendor.dashboard')}}"><i class="icon ion-md-analytics"></i> {{__("Fornecedor Dashboard")}}</a></li>

                                    @endif

                                    <li class="@if(Auth::user()->hasPermission('dashboard_vendor_access')) menu-hr @endif">

                                        <a href="{{route('user.profile.index')}}"><i class="icon ion-md-construct"></i> {{__("Meu perfil")}}</a>

                                    </li>

                                    @if(setting_item('inbox_enable'))

                                    <li class="menu-hr"><a href="{{route('user.chat')}}"><i class="fa fa-comments"></i> {{__("Reservas")}}</a></li>

                                    @endif

                                    <li class="menu-hr"><a href="{{route('user.booking_history')}}"><i class="fa fa-clock-o"></i> {{__("Histórico de Reservas")}}</a></li>

                                    <li class="menu-hr"><a href="{{route('user.change_password')}}"><i class="fa fa-lock"></i> {{__("Alterar senha")}}</a></li>

                                    @if(Auth::user()->hasPermission('dashboard_access'))

                                    <li class="menu-hr"><a href="{{url('/admin')}}"><i class="icon ion-ios-ribbon"></i> {{__("Admin Dashboard")}}</a></li>

                                    @endif

                                    <li class="menu-hr">

                                        <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> {{__("Sair")}}</a>

                                    </li>

                                </ul>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">

                                    {{ csrf_field() }}

                                </form>

                            </li>

                            @endif

                        </ul>

                        @endif

                        <button class="bravo-more-menu">

                            <i class="fa fa-bars"></i>

                        </button>

                    </div>

                </div>

            </div>

            <div class="bravo-menu-mobile" style="display:none;">

                <div class="user-profile">

                    <div class="b-close"><i class="icofont-scroll-left"></i></div>

                    <div class="avatar"></div>

                    <ul>

                        @if(!Auth::id() || Auth::user() === null )

                        <li>

                            <a href="#login" data-toggle="modal" data-target="#login" class="login">{{__('Login')}}</a>

                        </li>

                        <li>

                            <a href="#register" data-toggle="modal" data-target="#register" class="signup">{{__('Sign Up')}}</a>

                        </li>

                        @else

                        <li>

                            <a href="{{route('user.profile.index')}}">

                                <i class="icofont-user-suited"></i> {{__("Oi, :Name",['name'=>Auth::user()->getDisplayName()])}}

                            </a>

                        </li>

                        <li>

                            <a href="{{route('user.profile.index')}}">

                                <i class="icon ion-md-construct"></i> {{__("Meu perfil")}}

                            </a>

                        </li>

                        @if(Auth::user()->hasPermission('dashboard_vendor_access'))

                        <li>

                            <a href="{{route('vendor.dashboard')}}">

                                <i class="icon ion-md-analytics"></i> {{__("Fornecedor Dashboard")}}

                            </a>

                        </li>

                        @endif

                        @if(Auth::user()->hasPermission('dashboard_access'))

                        <li>

                            <a href="{{url('/admin')}}"><i class="icon ion-ios-ribbon"></i> {{__("Admin Dashboard")}}</a>

                        </li>

                        @endif

                        <li>

                            <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form-mobile').submit();">

                                <i class="fa fa-sign-out"></i> {{__("Sair")}}

                            </a>

                            <form id="logout-form-mobile" action="{{ route('logout') }}" method="POST" style="display: none;">

                                {{ csrf_field() }}

                            </form>

                        </li>



                        @endif

                    </ul>

                    <ul class="multi-lang">

                        @include('Core::frontend.currency-switcher-dropdown')

                    </ul>

                </div>

                <div class="g-menu">

                    <?php generate_menu('primary') ?>

                </div>

            </div>

        </div>

    </div>

</header>