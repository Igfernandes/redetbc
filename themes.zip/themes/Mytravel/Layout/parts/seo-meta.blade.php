@if(!empty($seo_meta))

    @if(isset($seo_meta['seo_index']) and $seo_meta['seo_index'] == 0)

        <meta name="robots" content="noindex">

    @endif

    @php

        $page_title = $seo_meta['seo_title'] ?? $seo_meta['service_title'] ?? $page_title ?? "";

        if(!empty($page_title) and empty($seo_meta['is_homepage'])){

            $page_title .= " - ".setting_item_with_lang('site_title' ,false,'My Travel');

        }

        if(empty($page_title)){

            $page_title = setting_item_with_lang('site_title' ,false,'My Travel');

        }

    @endphp

    <title>{{ $page_title }}</title>

    <meta name="description" content="{{$seo_meta['seo_desc'] ?? $seo_meta['service_desc'] ?? setting_item_with_lang("site_desc")}}"/>

    {{-- Facebook share --}}

    <meta property="og:url" content="{{$seo_meta['full_url'] ?? ""}}"/>

    <meta property="og:type" content="article"/>

    <meta property="og:title" content="{{$seo_meta['seo_share']['facebook']['title'] ?? $seo_meta['seo_title'] ?? $seo_meta['service_title'] ?? $page_title ?? ""}}"/>

    <meta property="og:description" content="{{$seo_meta['seo_share']['facebook']['desc'] ?? $seo_meta['seo_desc'] ?? $seo_meta['service_desc'] ?? ""}}"/>

    <meta property="og:image" content="{{ get_file_url( $seo_meta['seo_share']['facebook']['image'] ?? $seo_meta['seo_image'] ?? $seo_meta['service_image'] ?? "" , "full") }}"/>

    {{-- Twitter share --}}

    <meta name="twitter:card" content="summary_large_image">

    <meta name="twitter:title" content="{{$seo_meta['seo_share']['twitter']['title'] ?? $seo_meta['seo_title'] ?? $seo_meta['service_title'] ?? $page_title ?? ""}}">

    <meta name="twitter:description" content="{{$seo_meta['seo_share']['twitter']['desc'] ?? $seo_meta['seo_desc'] ?? $seo_meta['service_desc'] ?? ""}}">

    <meta name="twitter:image" content="{{ get_file_url( $seo_meta['seo_share']['twitter']['image'] ?? $seo_meta['seo_image'] ?? $seo_meta['service_image'] ?? "" , "full") }}">

    <link rel="canonical" href="{{$seo_meta['full_url'] ?? ""}}"/>

@else

    @php

        if(!empty($page_title)){

            $page_title .= " - ".setting_item_with_lang('site_title' ,false,'My Travel');

        }else{

            $page_title = setting_item_with_lang('site_title' ,false,'My Travel');

        }

    @endphp

<title>{{ $page_title }}</title>
<!-- Developer www.agencianaweb.com.br -->
<meta http-equiv="Content-Language" content="pt-br">
<meta name="document-classification" content="Site Institucional">
<meta name="REVISIT-AGENCIANAWEB" content="1 days">
<meta name="LANGUAGE" content="Portuguese">
<meta name="COPYRIGHT" content="www.agencianaweb.com.br">
<meta name="robots" content="all"/>
<meta name="googlebot" content="all"/>
<meta name="audience" content="all">
<meta name="copyright" content="Copyright (c) Agencia na Web. Todos os Direitos Reservados.">
<meta name="description" content="{{setting_item_with_lang("site_desc")}}"/>

@endif
